## Look at here

- → Did you read the doc carefully
- → Did you add annotation above target activity
- → Did you add annotation processor dependence
- → **Receive only bugs and suggestions**

## 提 issue 前请看

- → 你是否已经熟读 [README](https://github.com/alibaba/ARouter/blob/master/README.md) ？
- → 你是否在每一个包含页面 or 服务的模块中依赖了 compiler sdk
- → **这里不是答疑的地方，仅接受 bug 和建议，答疑请去答疑群**